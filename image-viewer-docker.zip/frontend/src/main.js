import { createApp } from 'vue'
import App from './App.vue'
import './index.css'  // <-- Tailwind CSS import

createApp(App).mount('#app')


